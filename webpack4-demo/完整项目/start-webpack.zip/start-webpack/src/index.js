import Vue from 'vue';
import App from './App.vue';

new Vue({
	el: "#app",
	template: "<App/>",
	// 注册组件
	components: {
		App
	}
})
