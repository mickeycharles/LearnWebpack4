<template>
	<div>
		<div class="title">{{ title }}</div>
		
		<section>
			<Python />
			<C />
			<Java />
			<JavaScript />
		</section>

	</div>
</template>

<script>

import Python from "./components/Python.vue";
import C from "./components/C.vue";
import Java from "./components/Java.vue";
import JavaScript from "./components/JavaScript.vue";

export default{

	data: function(){
		return {
			title: "编程语言介绍"
		}
	},
	// 注册组件
	components: { 
		Python,
		C,
		Java,
		JavaScript
	}
}	
</script>


// 组件样式独立 , 且使用less语法解析
<style scoped lang="less">
.title{
	color: #62868D;
	font-size: 50px;
	section{
		height: 100px;
	}
}	
</style>