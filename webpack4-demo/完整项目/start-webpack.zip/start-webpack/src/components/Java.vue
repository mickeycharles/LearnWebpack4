<template>
	
	<article>
		<img src="../images/java.png" height="100" alt="">
		{{title}}
		<p v-for="item in items">-> {{ item }}</p>

	</article>


</template>


<script>
export default {
	data: function() {
		return {
			title: "Java",
			items: ["Java是一门面向对象编程语言","吸收了C++语言的优点","摒弃了C++里多继承、指针等概念"]
		}
	}
}

</script>


<style scoped lang="less">
	article {
		font-size: 50px;
		color: #E3E8DD;
		background-color: #4783B6;
		p{
			font-size: 20px;
		}
	}
	img{
		margin-top: 50px;
		margin-left: 50px;

	}	
</style>

// 