<template>
	
	<article>
		<img src="../images/python.jpg" height="100" alt="">
		{{title}}
		<p v-for="item in items">-> {{item}}</p>
	</article>


</template>


<script>

export default {
	data: function() {
		return {
			title: "Python",
			items: ["是一种面向对象的解释型计算机程序设计语言","由荷兰人Guido van Rossum于1989年发明","第一个公开发行版发行于1991年"]
		}
	}

}

</script>


<style scoped lang="less">
	article {
		font-size: 50px;
		color: #E3E8DD;
		background-color: #62868D;
		p{
			font-size: 20px;
		}
	}
	img{

		margin-top: 50px;
		margin-left: 50px;

	}	
</style>