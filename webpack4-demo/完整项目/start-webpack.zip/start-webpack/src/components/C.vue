<template>
	
	<article>
		<img src="../images/c.png" height="100" alt="">
		{{title}}
		<p v-for="item in items">-> {{ item }}</p>
	</article>


</template>


<script>

export default {
	data: function() {
		return {
			title: "C语言",
			items: ["C 语言是一种通用的、面向过程式的计算机程序设计语言", 
			"1972 年，为了移植与开发 UNIX 操作系统，丹尼斯·里奇在贝尔电话实验室设计开发了 C 语言。","C 语言是一种广泛使用的计算机语言，它与 Java 编程语言一样普及，二者在现代软件程序员之间都得到广泛使用"]

		}
	}

}

</script>


<style scoped lang="less">
	article {
		font-size: 50px;
		color: #E3E8DD;
		background-color: #413F43;
		p{
			font-size: 20px;
		}
	}
	img{

		margin-top: 50px;
		margin-left: 50px;

	}
	
</style>