<template>
	
	<article>
		<img src="../images/javascript.png" height="100" alt="">		
		{{title}}
		<p v-for="item in items">-> {{ item }}</p>

	</article>


</template>


<script>

export default {
	data: function() {
		return {

			title: "JavScript",
			items: ["JavaScript一种直译式脚本语言","是一种动态类型、弱类型、基于原型的语言","JavaScript是一种属于网络的脚本语言"]

		}
	}

}

</script>


<style scoped lang="less">
	article {
		font-size: 50px;
		color: #E3E8DD;
		background-color: #5EA1F3;
		p{
			font-size: 20px;
		}
	}
	img{
		margin-top: 50px;
		margin-left: 50px;

	}	
</style>