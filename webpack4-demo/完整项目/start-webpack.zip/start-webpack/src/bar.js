export default function bar() {
	alert("Hello bar");
}